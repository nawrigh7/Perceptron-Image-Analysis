import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

import java.io.*;

public class ImageCreator_Tester {

    /*
     * Files and Filenames for testing
     */

     String path = "input_files/errorCases/";
     String invalidFormat = path + "3invalidFormat.txt";
     String invalidWidth = path + "4invalidWidth.txt";
     String invalidHeight = path + "5invalidHeight.txt";
     String invalidPx = path + "6invalidPx.txt";
     String invalidInts = path + "7invalidInts.txt";
     String invalidEmpty = path + "8invalidEmpty.txt";
     String invalidDims = path + "10invalidDims.txt";
     String invalidFile = path + "11invalidFile.txt";
     String invalidValueHigh = path + "12invalidValueHigh.txt";
     String invalidValueLow = path + "13invalidValueLow.txt";
     String[] errorCases = {invalidFormat, invalidWidth, invalidHeight, invalidPx, 
                            invalidInts, invalidEmpty, invalidDims, invalidFile, invalidValueHigh, 
                            invalidValueLow};

    String correct = "input_files/correctfiles.txt";

    @RepeatedTest (10)
    void failConditionsThrowExceptions() {
        assertThrows(ImageCreatorException.class, ()->{
            for(int i=0; i<errorCases.length; i++) {
                ImageCreator failingIC = new ImageCreator(errorCases[i]);
            }
        });
    }

    // Correct files should be able to create successfully
    @Test
    void objectCreationSuccess() throws ImageCreatorException, ExtensionException {
        ImageCreator imgC = new ImageCreator(correct);
        assertTrue(imgC.isValid);
    }
    @Test
    void defaultConstructorDoesNothing() {
        ImageCreator imgC = new ImageCreator();
        assertFalse(imgC.isValid);
    }
}
