import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class CS_214_Project_Tester {

    /*
     * CS_214_Project Testing
     */

     // Zero Args should fail
     @Test
     void zeroArgsFails() {
        assertThrows(ArgsException.class, ()->{
            String[] args = new String[0];
            CS_214_Project.main(args);
        });
     }
     // Too many args fails
     @Test
     void tooManyArgsFails() {
        assertThrows(ArgsException.class, ()->{
            String[] args = {"This", "array", "fails", "hard"};
            CS_214_Project.main(args);
        });
     }

     // Correct args pass
     // gradle run -q --args="'input_files/correctfiles.txt' '4' '1'"
     @Test
     void correctArgsNormHistPass() throws ArgsException, ImageCreatorException, ExtensionException, InvalidHistogramException {
        String[] args = {"input_files/correctfiles.txt", "4", "1"};
        CS_214_Project.main(args);
        assertTrue(CS_214_Project.runComplete);
     }
     // gradle run -q --args="'input_files/correctfiles.txt' '4' '3'"
     @Test
     void correctArgsInvSquarePass() throws ArgsException, ImageCreatorException, ExtensionException, InvalidHistogramException {
      String[] args = {"input_files/correctfiles.txt", "4", "3"};
      CS_214_Project.main(args);
      assertTrue(CS_214_Project.runComplete);
     }
     // gradle run -q --args="'input_files/correctfiles.txt' '3' '2'"
     @Test
     void correctArgsNormHist4Pass() throws ArgsException, ImageCreatorException, ExtensionException, InvalidHistogramException {
      String[] args = {"input_files/correctfiles.txt", "3", "2"};
      CS_214_Project.main(args);
      assertTrue(CS_214_Project.runComplete);
     }
}