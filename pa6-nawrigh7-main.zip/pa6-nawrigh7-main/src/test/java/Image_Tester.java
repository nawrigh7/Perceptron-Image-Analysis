import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;

import org.junit.jupiter.api.Test;

public class Image_Tester {

    File validImage = new File("input_files/twofiles.txt");

    // Default constructor just initiates values to null / 0
    @Test
    void imageDefaultConstructor() {
        Image img = new Image();
        assertEquals(-10.0, img.similarityToImage);
    }

    // addSimilarity should update similarity value
    @Test
    void addSimilarityUpdatesValue() {
        Image img = new Image();
        img.addSimilarity("soSimilar.pgm", 1.0);
        assertEquals(1.0, img.similarityToImage);
    }

}
