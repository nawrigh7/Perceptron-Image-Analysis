

public class InvSquareDiff {

    /*
     * Class Members
     */
    final Integer EXPECTED_DIMS = 128*128;
    Double[] centroidOne;
    Double[] centroidTwo;
    Double similarity;

    public InvSquareDiff() {
        this.similarity = -20.0;
    }

    public InvSquareDiff(Cluster clusterOne, Cluster clusterTwo) {
        this.centroidOne = clusterOne.clusterCentroid;
        this.centroidTwo = clusterTwo.clusterCentroid;
        calculateSimilarity();
    }


    private void calculateSimilarity() {
        this.similarity = 0.0;
        this.similarity += (1 / (calculateDiffSum())+1);
    }

    private Double calculateDiffSum() {
        Double pxDiff = 0.0;

        for(int i=0; i<EXPECTED_DIMS; i++) {
            pxDiff += Math.pow((this.centroidTwo[i] - this.centroidOne[i]), 2);
            
        }
        return pxDiff;
    }


}





