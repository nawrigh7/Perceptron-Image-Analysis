import java.util.HashMap;

public class NormHistFour {

    /*
     * Class Members
     */
    //Double[] similarities = new Double[4];
    Double similarity;
    final static int QUARTER_OF_ENTRIES = 4096;
    final static int WIDTH = 128;
    final static int HISTOGRAM_LENGTH = 64;
    HashMap<Integer, Double[]> clusterOneQuarters = new HashMap<>();
    HashMap<Integer, Double[]> clusterTwoQuarters = new HashMap<>();
    HashMap<Integer, Double[]> clusterOneQuarterHistograms = new HashMap<>();
    HashMap<Integer, Double[]> clusterTwoQuarterHistograms = new HashMap<>();
    Cluster clusterOne;
    Cluster clusterTwo;


    public NormHistFour() {
        this.similarity = -100.0;
    }

    public NormHistFour(Cluster clusterOne, Cluster clusterTwo) {
        this.clusterOne = clusterOne;
        this.clusterTwo = clusterTwo;
        populateMaps();
        getSimilarity();
        //compare();
        
    }

    private void populateMaps() {
        for(int i=0; i<4; i++) {
            this.clusterOneQuarters.put(i, new Double[QUARTER_OF_ENTRIES]);
            this.clusterTwoQuarters.put(i, new Double[QUARTER_OF_ENTRIES]);
            this.clusterOneQuarterHistograms.put(i, new Double[HISTOGRAM_LENGTH]);
            this.clusterTwoQuarterHistograms.put(i, new Double[HISTOGRAM_LENGTH]);
            getQuarter(i);
            setHistogram(i);
            createHistogram(i);
            normalize(i);
        }
    }

    // Index in (x, y) terms is i = x + (width*y)
    // So (0, 0) = 0 + (0*128);
    // (1, 1) = 1 + (1*128);
    private void getQuarter(int quarter) {
        int x, y;
        switch (quarter) {
            case 0:
                x = 0;
                y = 0;
                break;
            case 1:
                x = 64;
                y = 0;
                break;
            case 2:
                x = 0;
                y = 64;
                break;
            case 3:
                x = 64;
                y = 64;
                break;
            default:
                x = 0;
                y = 0;
                break;
        }

        for(int i=0; i<QUARTER_OF_ENTRIES; i++) {
            this.clusterOneQuarters.get(quarter)[i] = this.clusterOne.clusterCentroid[(x + (y * WIDTH))];
            this.clusterTwoQuarters.get(quarter)[i] = this.clusterTwo.clusterCentroid[(x + (y * WIDTH))];
        }
        
    }

    private void setHistogram(int quarter) {
        for(int i=0; i<HISTOGRAM_LENGTH; i++) {
            this.clusterOneQuarterHistograms.get(quarter)[i] = 0.0;
            this.clusterTwoQuarterHistograms.get(quarter)[i] = 0.0;
        }
    }

    private void createHistogram(int quarter) {
        for(Double d : this.clusterOneQuarters.get(quarter)) {
            int k = (int)Math.floor(d/4);
            this.clusterOneQuarterHistograms.get(quarter)[k] += 1;
        }
        for(Double d : this.clusterTwoQuarters.get(quarter)) {
            int k = (int)Math.floor(d/4);
            this.clusterTwoQuarterHistograms.get(quarter)[k] += 1;
        }
    }

    private void normalize(int quarter) {
        Double sumOne = getSum(this.clusterOneQuarterHistograms.get(quarter));
        Double sumTwo = getSum(this.clusterTwoQuarterHistograms.get(quarter));
        for(int i=0; i<HISTOGRAM_LENGTH; i++) {
            this.clusterOneQuarterHistograms.get(quarter)[i] = this.clusterOneQuarterHistograms.get(quarter)[i] / sumOne;
            this.clusterTwoQuarterHistograms.get(quarter)[i] = this.clusterTwoQuarterHistograms.get(quarter)[i] / sumTwo;
        }
    }

    private Double getSum(Double[] histogram) {
        Double sum = 0.0;
        for(Double d : histogram) {
            sum += d;
        }
        return sum;
    }

    private void getSimilarity() {
        this.similarity = 0.0;
        for(int i=0; i<4; i++) {
            Comparitor comp = new Comparitor(clusterOneQuarters.get(i), clusterTwoQuarters.get(i), 1);
            this.similarity += comp.similarity;
            //this.similarities[i] = compareQuarter(i);
        }
        /*for(Double d : this.similarities) {
            this.similarity += d;
        }*/
        this.similarity /= 4;
    }

    /*private Double compareQuarter(int quarter) {
        Double sum = 0.0;
        for(int i=0; i<HISTOGRAM_LENGTH; i++) {
            if(this.clusterOneQuarterHistograms.get(quarter)[i] <= this.clusterTwoQuarterHistograms.get(quarter)[i]) {
                sum += this.clusterOneQuarterHistograms.get(quarter)[i];
            }else {
                sum += this.clusterTwoQuarterHistograms.get(quarter)[i];
            }
        }
        return sum;
    }*/

}
