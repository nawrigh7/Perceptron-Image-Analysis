import java.util.ArrayList;
import java.io.File;

/**
 * <b>Class - CS_214_Project</b>
 * <p>This is the main driver class for this program. The goal of this program is to</p>
 * <p>read in a file that contains the filenames of image files, and then compare those</p>
 * <p>images to each other with one of three comparison measures, then group them into</p>
 * <p>a specified number of clusters of similarity. At the command line, the file name, </p>
 * <p>number of clusters, and comparison type should be provided.</p>
 * <p>For comparison types, 1 = Comparison by normalized Histogram ("NormHist"),</p>
 * <p>2 = Comparison by the histograms of the image split into quarters ("NormHist4")</p>
 * <p>and 3 = Direct pixel comparison using the inverse of square differences ("InvSquareDiff")</p>
 */
public class CS_214_Project {

    /*
     * Class Members
     */
    static ArrayList<Image> imageList = new ArrayList<>();
    static final Double NOT_COMPARED = -1000.0;
    static final int EXPECTED_ARGS = 3;
    static String fileName;
    static int numClusters;
    static int SELECTION = 0;
    static boolean runComplete = false;

    /**
     * <b>Main</b>
     * @param args String array supplied at command line. Expected to be a .txt file, number of clusters (1-#images), and comparison type (1-3)
     * @throws ArgsException Used for invalid argument error handling
     * @throws ImageCreatorException Used if the image files cannot be found, are empty, or otherwise do not meet the necessary specifications
     * @throws ExtensionException Used for file extension checking
     * @throws InvalidHistogramException Used for error handling while reading the raw data into a Histogram object
     */
    public static void main(String[] args) throws ArgsException, ImageCreatorException, ExtensionException, InvalidHistogramException{
        if(args.length != EXPECTED_ARGS) {
            throw new ArgsException("Invalid number of arguments entered.");
        }
        checkArgs(args);
        
        run(fileName);
        runComplete = true;
    }

    /**
     * <b>Method - checkArgs</b>
     * <p>This method checks the supplied arguments for validity.</p>
     * @param args The arguments supplied at the command line
     * @throws ArgsException Thrown if any argument is found to be invalid.
     */
    private static void checkArgs(String[] args) throws ArgsException {
        ExtensionChecker checkTxt = new ExtensionChecker(".txt");
        try{
            checkTxt.checkExtension(args[0]);
            fileName = args[0];
        }catch(ExtensionException e) {
            throw new ArgsException("The supplied argument is not a valid .txt file");
        }
        try{
            numClusters = Integer.parseInt(args[1]);
            if(numClusters < 1) {
                throw new ArgsException("The second argument must be an integer between 1 and the number of images in the file.");
            }
        } catch(NumberFormatException e) {
            throw new ArgsException("The second argument must be an integer between 1 and the number of images in the file.");
        }
        try{
            SELECTION = Integer.parseInt(args[2]);
            if(SELECTION < 1 || SELECTION > 3) {
                throw new ArgsException("The third argument must be an integer from 1 to 3, to indicate the desired type of comparison.");
            }
        } catch(NumberFormatException e) {
            throw new ArgsException("The third argument must be an integer from 1 to 3.");
        }
    }

    /**
     * <b>Method - run</b>
     * <p>Driver method for the functionality of the code. Only executes if the checkArgs method passes</p>
     * @param fileName The name of the file supplied at the command line
     * @throws ImageCreatorException Thrown if the ImageCreator encounters an invalid file
     * @throws ExtensionException Thrown if a file is found to have an incorrect extension (not .txt in this case)
     * @throws InvalidHistogramException Thrown if a Histogram encounters an error
     * @throws ArgsException Thrown if any argument is invalid or missing.
     */
    private static void run(String fileName) throws ImageCreatorException, ExtensionException, InvalidHistogramException, ArgsException {
        ImageCreator imageCreator = new ImageCreator(fileName);
        for(File f : imageCreator.imageList) {
            imageList.add(new Image(f));
        }
        if(numClusters > imageList.size()) {
            throw new ArgsException("There aren't enough images to make that many clusters.");
        }
        ArrayList<Cluster> clusterList = new ArrayList<>();
        for(Image img : imageList) {
            clusterList.add(new Cluster(img, SELECTION));
        }
        Agglomerative agglo = new Agglomerative(clusterList, numClusters, SELECTION);
        for(Cluster c : agglo.clusterList) {
            System.out.println(c);
        }
        //compareImages();
    }

    /*private static void compareImages() {
        for(int i=0; i<imageList.size(); i++) {
            compareToList(imageList.get(i), i);
        }
    }

    private static void compareToList(Image imageToCompare, int index) {
        for(int i=0; i<imageList.size(); i++) {
            if(i == index) {
                continue;
            }
            Comparitor comp = new Comparitor(imageToCompare.imageHistogram.normalized, imageList.get(i).imageHistogram.normalized);
            if(comp.similarity > imageToCompare.similarityToImage) {
                imageToCompare.similarityToImage = comp.similarity;
                imageToCompare.similarImage = imageList.get(i).imageName;
            }
        }
    }*/
}