public class ImageCreatorException extends Exception{
    public ImageCreatorException(String message) {
        System.err.println("Error: " + message);
    }
}
