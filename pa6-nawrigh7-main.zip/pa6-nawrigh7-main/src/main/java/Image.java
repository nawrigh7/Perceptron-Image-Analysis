import java.io.File;

public class Image{
    /*
     * Class Members
     */
    String imageName;
    File imageFile;
    int HISTOGRAM_LENGTH = 64;
    Histogram imageHistogram;
    String similarImage;
    Double similarityToImage;
    
    public Image() {
        this.imageName = null;
        this.similarImage = null;
        this.similarityToImage = -10.0;
    }

    public Image(File imageFile) throws InvalidHistogramException{
        this.imageFile = imageFile.getAbsoluteFile();
        this.imageName = this.imageFile.getName();
        this.similarImage = "";
        this.similarityToImage = -3.0;
        this.imageHistogram = new Histogram(this.imageFile);
    }
    
    public void addSimilarity(String similarImage, Double similarityToImage) {
        this.similarImage = similarImage;
        this.similarityToImage = similarityToImage;
    }

    public String toString() {
        return this.imageName/* + " " + this.similarImage + String.format(" %.6f", similarityToImage)*/;
    }
}
