import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class ImageCreator extends FileValidator{

    /*
     * Class Members
     */
    String fileName;
    File inputFile;
    boolean isValid;
    Scanner scan;
    ArrayList<File> imageList = new ArrayList<>();
    static final String expectedFormat = "P3";
    static final String imageExtension = ".pgm";
    // This applies to the height as well, and will be used as such. For pa6 req's, the image must be 128x128
    static final Integer EXPECTED_WIDTH = 128;
    static final Integer EXPECTED_HEIGHT = 128;
    static final Integer EXPECTED_DIMS = EXPECTED_WIDTH * EXPECTED_HEIGHT;


    public ImageCreator() {
        this.isValid = false;
    }

    public ImageCreator(String fileName) throws ImageCreatorException, ExtensionException {
        this.fileName = new File(fileName).getAbsolutePath();
        this.inputFile = new File(this.fileName).getAbsoluteFile();
        this.isValid = false;
        try{
            validate();
        } catch (FileNotFoundException e) {
            System.err.println("the file " + this.fileName + " was not found.");
        } catch (InvalidFileException f) {
            System.err.println("the file " + this.fileName + " was found to be empty.");
        }
        
    }

    private void validate() throws FileNotFoundException, InvalidFileException, ImageCreatorException, ExtensionException {
        if(exists(this.inputFile) && notEmpty(this.inputFile)) {
            createList();
            isValid = checkImageListContents();
        }
    }

    private void createList() throws FileNotFoundException, ImageCreatorException, ExtensionException {
        scan = new Scanner(this.inputFile);
        ExtensionChecker pgmChecker = new ExtensionChecker(imageExtension);
        while(scan.hasNextLine()) {
            String lineFromFile = scan.nextLine().trim();
            if(lineFromFile.length() == 0) {
                continue;
            }
            if(pgmChecker.checkExtension(lineFromFile)){
                this.imageList.add(new File(lineFromFile).getAbsoluteFile());
            }
        }
        scan.close();
    }

    private boolean checkImageListContents() throws FileNotFoundException, InvalidFileException, ImageCreatorException {
        for(File image : imageList) {
            if(exists(image) && notEmpty(image)) {
                checkFormat(image);
                checkOnlyContainsInts(image);
                checkDims(image);
            }
        }
        return true;
    }

    @Override
    protected boolean exists(File image) throws InvalidFileException {
        return super.exists(image);
    }
    @Override
    protected boolean notEmpty(File image) throws FileNotFoundException, InvalidFileException {
        return super.notEmpty(image);
    }

    private void checkFormat(File image) throws ImageCreatorException {
        try{
            scan = new Scanner(image);
            if(!scan.next().equals(expectedFormat)) {
                scan.close();
                throw new ImageCreatorException("the expected format value of P3 was not found in file " + image.getName());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void checkOnlyContainsInts(File image) throws ImageCreatorException {
        try {
            scan = new Scanner(image);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        scan.next();
        int x;
        while(scan.hasNext()) {
            try{
                x = Integer.parseInt(scan.next());
                if(x < 0 || x > 255) {
                    scan.close();
                    throw new ImageCreatorException("an integer value is outside of the 0-255 range in " + image.getName());
                }
            } catch(NumberFormatException e) {
                scan.close();
                throw new ImageCreatorException("Error: the file " + image.getName() + " contains a non-integer value.");
            }
        }
    }

    private void checkDims(File image) throws ImageCreatorException {
        try {
            scan = new Scanner(image);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        scan.next();
        int width = scan.nextInt();
        if(width != EXPECTED_WIDTH) {
            throw new ImageCreatorException("the width in the file " + image.getName() + " of " + width + " is not the expected value of 128.");
        }
        int height = scan.nextInt();
        if(height != EXPECTED_HEIGHT) {
            throw new ImageCreatorException("the height in the file " + image.getName() + " of " + height + " is not the expected value of 128.");
        }
        int pixel = scan.nextInt();
        if(pixel < 0 || pixel > 255) {
            throw new ImageCreatorException("the Pixel value in the file " + image.getName() + " of " + pixel + " is not within the 0-255 range.");
        }
        int count = 0;
        while(scan.hasNext()) {
            scan.next();
            count++;
        }
        if(count != EXPECTED_DIMS) {
            throw new ImageCreatorException("the file " + image.getName() + " does not have the expected dimensions of " + EXPECTED_DIMS);
        }
    }
}
